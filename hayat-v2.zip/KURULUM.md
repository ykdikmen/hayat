# Hayat Paneli 2.0

## Yeni olanlar
- **Bugün**: saate göre değişen gökyüzü kartı (Roma silueti), Vespa göstergesi gibi "gün skoru", sıradaki iş, şimdi çizgili program, kısa tur özeti (rehbersiz / kapanmamış turlar), posta kartı, alışkanlıklar, günün harcaması.
- **Para**: gider/gelir girişi (kategori çipleri), aylık net, bütçe çubuğu, "nereye gidiyor" dağılımı, günlük gider grafiği, sigaranın aylık maliyeti, kayıt listesi. Sesle de olur: "12 euro öğle yemeği", "50 euro bahşiş kazandım".
- **Günlük**: ruh hali / enerji / odak, yatış-kalkış saatinden otomatik uyku, sabah niyeti, akşam soruları, 3 şükür, serbest not, kazanımlar, sağlık, "Kendini tanı" (5 günden sonra kendi kalıpların), geçmiş günler.
- **İlerleme**: Hafta, Alışkanlık (aylık tablo + "Takip etmeye değer" önerileri: kahve, alkol, ekran süresi, adım, nefes, kilo…), Hedefler.
- **Claude (zil ikonu)**: Bildirimler akışı, Posta özetleri, Sohbet, Ayarlar (bildirim izni, bütçe, sigara paketi fiyatı, tema).
- **Ortadaki mikrofon**: her yerden söyle/yaz; basit kayıtları uygulama anında işler, gerisi Claude'a gider.
- **Hatırlatma**: uygulama açıkken plan saatinden 5 dk önce bildirim; maddedeki zile dokununca Google Takvim'e eklenir (uygulama kapalıyken de çalar).

## Yükleme (bir kez)
**Yol A, en kolayı:** Claude ile kod oturumunda ykdikmen/hayat deposunu oturuma ekle, bu zip'i ver ve "yükle" de.

**Yol B, elle (bilgisayardan 5 dk):**
1. github.com/ykdikmen/hayat → **Add file → Upload files**
2. Zip'teki 6 dosyayı sürükle: index.html, sw.js, manifest.webmanifest, ikon-180.png, ikon-192.png, ikon-512.png (eskilerin üzerine yazar).
3. **Commit changes**. 1-2 dakika sonra telefonda uygulamayı kapatıp aç.

Giriş bilgin telefonda kalır; tekrar link yapıştırman gerekmez. Ana ekrandaki ikonun yeni görünümü için ikonu silip "Ana Ekrana Ekle" ile yeniden eklemen gerekebilir (bu durumda giriş linkini bir kez yapıştırırsın).

## Teknik notlar
- Google tarafındaki Apps Script değişmedi. Veriler aynı tabloda; gün kayıtlarına yeni alanlar eklenir: `para`, `gunluk`, `uykuSaat`, `v: 2`.
- Uygulama Claude için iki açık istek tutar: "📬 POSTA" (posta görevi cevaplar, günde 4 kez) ve "📣 BRİFİNG" (sabah, öğle ve gece görevleri cevaplar). Saatlik gelen kutusu görevi bunlara dokunmaz.
- Claude'un cevabında `[[uygula {"ops":[...]}]]` bloğu varsa uygulama bunu bir kez işler (para, günlük, uyku) ve bloğu gizler.
- Eski sürüm git geçmişinde duruyor; geri dönmek bir tık.
- Sınır: uygulama tamamen kapalıyken kendi bildirimini gönderemez (bunun için bir push sunucusu gerekir). O yüzden zil → Google Takvim yolu var; sonraki adım olarak Apps Script'e web-push eklenebilir.
